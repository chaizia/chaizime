# GitStatic
1.下载插件

2.文件目录更名GitStatic

3.到github获取token 用户名 仓库名

4.填入插件设置

5.上传图片即可
