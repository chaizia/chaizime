<?php
/**
* 使用该文件可以搭建一个属于自己的插件授权服务器
*
* @author : 无绘
* @time : 2021.8.27
* @version : 4.0
*/
//请抽取本文件 class目录 auth.php 文件到Server
require 'class/GithubApi.php';
//二次验证待开发